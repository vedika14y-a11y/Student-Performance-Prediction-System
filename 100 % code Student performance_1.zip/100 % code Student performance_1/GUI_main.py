import tkinter as tk
from tkinter import ttk, LEFT, END

from tkinter.filedialog import askopenfilename
from tkinter import messagebox as ms

import sqlite3
import os
import numpy as np

from tkvideo import tkvideo

global fn
fn = ""

root = tk.Tk()
root.configure(background="brown")


w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))
root.title("Student Performance Prediction System")


video_label =tk.Label(root)
video_label.pack()
# read video to display on label
player = tkvideo("studentvideo.mp4", video_label,loop = 1, size = (w, h))
player.play()


#label
label_l1 = tk.Label(root, text="Student Performance Prediction System",font=("Times New Roman", 35, 'bold'),
                    background="Maroon", fg="white", width=60, height=2)
label_l1.place(x=0, y=0)


#functions
def reg():
    from subprocess import call
    call(["python","registration.py"])

def log():
    from subprocess import call
    call(["python","log.py"])
    
def window():
  root.destroy()


button1 = tk.Button(root, text="Login", command=log, width=12, height=1,font=('times', 20, ' bold '), bg="Purple", fg="white")
button1.place(x=80, y=160)

button2 = tk.Button(root, text="Register",command=reg,width=12, height=1,font=('times', 20, ' bold '), bg="Purple", fg="white")
button2.place(x=80, y=260)

button3 = tk.Button(root, text="Exit",command=window,width=12, height=1,font=('times', 20, ' bold '), bg="red", fg="white")
button3.place(x=80, y=360)

root.mainloop()