import tkinter as tk
from tkinter import messagebox
import webbrowser
from tkinter import ttk

class StudentClassifier:
    def __init__(self, marks):
        self.marks = marks

    def average(self):
        return sum(self.marks) / len(self.marks)

    def classify(self):
        avg = self.average()
        if avg > 75:
            return "Distinction"
        elif avg > 50:
            return "Medium"
        else:
            return "Low"

class AppGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Performance Prediction System")
        self.root.geometry("800x850")
        self.root.configure(bg="#f7f8fa")

        self.entries = []
        self.current_subjects = []

        # Expanded subject map with additional subjects for each semester
        self.subject_map = {
            "Computer Engineering": {
                "1st": ["Fundamentals of IT", "Applied Math I", "Communication Skills", "Engineering Mathematics"],
                "2nd": ["Digital Electronics", "C Programming", "Computer Graphics", "Discrete Mathematics"],
                "3rd": ["Data Structures", "Database Management", "Operating Systems", "Computer Organization"],
                "4th": ["Java Programming", "Computer Networks", "Software Engineering", "Web Technologies"],
                "5th": ["Mobile App Development", "Web Development", "Python", "Cloud Computing"],
                "6th": ["Project", "Advanced Java", "Cloud Computing", "Artificial Intelligence"]
            },
            "Electronics": {
                "1st": ["Basic Electronics", "Applied Physics", "Mathematics I", "Engineering Mechanics"],
                "2nd": ["Electronic Devices", "Digital Circuits", "Network Analysis", "Mathematics II"],
                "3rd": ["Microprocessors", "Instrumentation", "Communication Systems", "Signals & Systems"],
                "4th": ["Embedded Systems", "VLSI Design", "PCB Design", "Control Systems"],
                "5th": ["Industrial Electronics", "Wireless Communication", "Power Electronics", "Electromagnetic Theory"],
                "6th": ["Project", "IoT", "Advanced Communication", "Digital Signal Processing"]
            },
            "Mechanical": {
                "1st": ["Engineering Drawing", "Applied Physics", "Workshop Practice", "Engineering Mechanics"],
                "2nd": ["Engineering Mechanics", "Thermodynamics", "Material Science", "Strength of Materials"],
                "3rd": ["Manufacturing Processes", "Fluid Mechanics", "Strength of Materials", "Theory of Machines"],
                "4th": ["Machine Drawing", "Metrology", "Metals & Alloys", "Hydraulics"],
                "5th": ["Refrigeration & AC", "Automobile Engineering", "CNC Machines", "Theory of Machines II"],
                "6th": ["Project", "CAD/CAM", "Industrial Engineering", "Production Management"]
            },
            "Civil": {
                "1st": ["Construction Materials", "Basic Surveying", "Engineering Drawing", "Mathematics I"],
                "2nd": ["Building Construction", "Concrete Technology", "Strength of Materials", "Geotechnical Engineering"],
                "3rd": ["Structural Mechanics", "Hydraulics", "Surveying II", "Building Design"],
                "4th": ["Transportation Engineering", "Steel Structures", "Soil Mechanics", "Water Resources Engineering"],
                "5th": ["Estimation & Costing", "RCC Design", "Water Resources Engineering", "Environmental Engineering"],
                "6th": ["Project", "Environmental Engineering", "Town Planning", "Advanced Surveying"]
            },
            "Electrical": {
                "1st": ["Basic Electrical Engg", "Applied Physics", "Wiring Practice", "Mathematics I"],
                "2nd": ["DC Machines", "Electrical Measurement", "Basic Electronics", "Network Theory"],
                "3rd": ["AC Machines", "Transmission & Distribution", "Electrical Instruments", "Electrical Machines"],
                "4th": ["Power Systems", "Switchgear", "Control Systems", "Electrical Power Generation"],
                "5th": ["Electrical Installation", "Microcontrollers", "Utilization of Electrical Energy", "Smart Grids"],
                "6th": ["Project", "Energy Management", "Industrial Automation", "Power Electronics"]
            }
        }

        self.video_links = {
    # Common / Core Subjects
    "Fundamentals of IT": "https://youtu.be/HcOc7P5BMi4",
    "Applied Math I": "https://youtu.be/MxzZO-wTncU",
    "Engineering Mathematics": "https://youtu.be/E3x6X45QG6A",
    "Mathematics I": "https://youtu.be/MxzZO-wTncU",
    "Mathematics II": "https://youtu.be/2tbC3YXymEY",
    "Applied Physics": "https://youtu.be/1vv3q9T1eXM",
    "Engineering Mechanics": "https://youtu.be/1ViFtbY7u9I",

    # Computer Engineering
    "C Programming": "https://youtu.be/KJgsSFOSQv0",
    "Computer Graphics": "https://youtu.be/gX6kz6Jb9hI",
    "Discrete Mathematics": "https://youtu.be/FXQ04F0f9yw",
    "Data Structures": "https://youtu.be/VTLCoHnyACE?si=h9S1aaIjXOM1sZ4o",
    "Database Management": "https://youtu.be/T7AxzI3D_Pw",
    "Operating Systems": "https://youtu.be/a1l4MceYHaQ",
    "Computer Organization": "https://youtu.be/Hl-zzrqQoSE",
    "Java Programming": "https://youtu.be/4XTsAAHW_Tc?si=zYdstK9_IOZvdEqi",
    "Computer Networks": "https://youtu.be/IPvYjXCsTg8",
    "Software Engineering": "https://youtu.be/xpKfOEjCeUc",
    "Web Technologies": "https://youtu.be/Q33KBiDriJY",
    "Mobile App Development": "https://youtu.be/7nQsQ0rvYqQ?si=hUcpIew_J-PRBohR",
    "Web Development": "https://youtu.be/a7_WFUlFS94?si=BeJokJSdXNJm5KkE",
    "Python": "https://youtu.be/ESnrn1kAD4E?si=a8z1yqPQQhrxwooJ",
    "Cloud Computing": "https://youtu.be/2LaAJq1lB1Q",
    "Advanced Java": "https://www.youtube.com/watch?v=Ae-r8hsbPUo",
    "Artificial Intelligence": "https://youtu.be/2ePf9rue1Ao",

    # Electronics
    "Basic Electronics": "https://youtu.be/TI2x5ytQF0U",
    "Electronic Devices": "https://youtu.be/N1WvWCdxMXA",
    "Digital Circuits": "https://youtu.be/oNhncQXfaCc",
    "Network Analysis": "https://youtu.be/yDqv4wN8w6Q",
    "Microprocessors": "https://youtu.be/CsJ9w8_vG30",
    "Instrumentation": "https://youtu.be/wWTN_O3kA3w",
    "Communication Systems": "https://youtu.be/tNFzQOvCjDQ",
    "Signals & Systems": "https://youtu.be/4Fj_jO64Pbs",
    "Embedded Systems": "https://youtu.be/FnGuYpQnV2c",
    "VLSI Design": "https://youtu.be/lk3qlWbdGC0",
    "PCB Design": "https://youtu.be/0RgIBkQacpE",
    "Control Systems": "https://youtu.be/dL3Nz1Kp3dY",
    "Industrial Electronics": "https://youtu.be/BopHCOhySk8",
    "Wireless Communication": "https://youtu.be/bA2vKiuUyg4",
    "Power Electronics": "https://youtu.be/1BAHjqkUGQ0",
    "Electromagnetic Theory": "https://youtu.be/LRDUzHooA2Y",
    "IoT": "https://youtu.be/EyqPzUjGk0A",
    "Advanced Communication": "https://youtu.be/VKrAj2aM-RE",
    "Digital Signal Processing": "https://youtu.be/pCEiXJ8D_mg",

    # Mechanical
    "Engineering Drawing": "https://youtu.be/46eJDJkZCMg",
    "Workshop Practice": "https://youtu.be/KGR3ETPOafA",
    "Thermodynamics": "https://youtu.be/LV3r0EXe4pI",
    "Material Science": "https://youtu.be/Z1tsQn0XWz8",
    "Strength of Materials": "https://youtu.be/fIFxMYfJCoM",
    "Manufacturing Processes": "https://youtu.be/Ap9LM7g9t2g",
    "Fluid Mechanics": "https://youtu.be/2f1N3ZVJgsY",
    "Theory of Machines": "https://youtu.be/dvj2KbEDP5Y",
    "Machine Drawing": "https://youtu.be/f1t5K6EKOMk",
    "Metrology": "https://youtu.be/7y2pKZ3ytK4",
    "Metals & Alloys": "https://youtu.be/7Ysw4ABUn7g",
    "Hydraulics": "https://youtu.be/Z3GmgLzW8nI",
    "Refrigeration & AC": "https://youtu.be/ZKQmtu_sUQg",
    "Automobile Engineering": "https://youtu.be/BzTZZJngqLg",
    "CNC Machines": "https://youtu.be/Yy_4HNmN1zM",
    "CAD/CAM": "https://youtu.be/J5QY1qpjNxM",
    "Industrial Engineering": "https://youtu.be/lsyH1xPNqD0",
    "Production Management": "https://youtu.be/IbV2N1ol7fY",

    # Civil
    "Construction Materials": "https://youtu.be/2ZlZYn_nmzY?si=6fz-hVHrER6G52LS",
    "Basic Surveying": "https://youtu.be/l7hhFozApMc?si=FfefFAkBdCdoa0Rj",
    "Building Construction": "https://www.youtube.com/live/w1ZOjg8UMLA?si=c-cKL1os4CrsFV38",
    "Concrete Technology": "https://www.youtube.com/live/2lVkj3cEZO0?si=A3sFAV1kQAzDqvZV",
    "Geotechnical Engineering": "https://www.youtube.com/live/eh3VSqsHicE?si=cKMODuUW1_nOV7Cr",
    "Structural Mechanics": "https://youtu.be/JrNUaJeSIiQ?si=uGYI6eTZCEJ8YqVC",
    "Hydraulics": "https://youtu.be/DdZnknku8b8?si=bop_8RxCW9ZTp1mN",
    "Building Design": "https://youtube.com/shorts/Sxnj_oFTkyI?si=0rSLEznlnfzKBSGA",
    "Transportation Engineering": "https://www.youtube.com/live/WYGS9CYlxho?si=qE7apX9pR56hIqGb",
    "Steel Structures": "https://youtu.be/77C94OldqsQ?si=17H0h-6aYQCOujOE",
    "Soil Mechanics": "https://www.youtube.com/live/C6eqXDGmkNY?si=KNlOsDLPg4hgoVGl",
    "Water Resources Engineering": "https://youtu.be/L1xY3GAJAV8?si=_qSdTTVlAWA3CsQY",
    "Estimation & Costing": "https://www.youtube.com/live/U3O8esxieu4?si=med6b1KzecEAc5kr",
    "RCC Design": "https://youtu.be/Eh4E7uBLR6E?si=rN9RA8tchIlH-ZSO",
    "Environmental Engineering": "https://youtu.be/y9eQ-NYOKPY?si=nsiMaeIexeoneg_S",
    "Town Planning": "https://youtu.be/ulyPxhtNEMQ?si=iXNYEUJJi-hFd65C",
    "Advanced Surveying": "https://youtu.be/BU0pbK-GNLs?si=lcCM-E2DKi1jV78b",

    # Electrical
    "Basic Electrical Engg": "https://youtu.be/Vd2UJiIPbag?si=S12gHdj-HnvKVmbm",
    "Wiring Practice": "https://youtu.be/kVFPkoOM3lQ?si=SeAWHy1SaWKLOypZ",
    "DC Machines": "https://youtu.be/oI-O9FCDqmg?si=HZvMldr6Damb_qq-",
    "Electrical Measurement": "https://www.youtube.com/live/_I-g0CFmXKg?si=AXF58MrrrmO1Be9T",
    "Network Theory": "https://youtu.be/NEhH6C7Fzw4?si=sqUhdMsMCEc2De4e",
    "AC Machines": "https://youtu.be/CWulQ1ZSE3c?si=zcKShKCKU0gNmG5-",
    "Transmission & Distribution": "https://youtu.be/jTcT1GNZCAA?si=bAhO_KU6R4I08ST6",
    "Electrical Instruments": "https://youtu.be/Mr3Od9ZFpHg?si=jgAlRyu5kxp1sT_Y",
    "Electrical Machines": "https://youtu.be/CWulQ1ZSE3c?si=_Yh27ZNtrrXLXa5M",
    "Power Systems": "https://youtu.be/pWd2b-F4STw?si=lTb6nQwUdhtosCIZ",
    "Switchgear": "https://youtu.be/octDApyb2QI?si=Uyn6PCoCvf9Cb8W1",
    "Control Systems": "https://youtu.be/HcLYoCmWOjI?si=AuVWT3J7LtFjDIo_",
    "Electrical Power Generation": "https://youtu.be/jlmBCPyP2-8?si=3atlkyaqcyyOiPiy",
    "Electrical Installation": "https://youtu.be/MTXH9po9hiI?si=z7pSlsfDj2HRiszl",
    "Microcontrollers": "https://youtu.be/e9unoOYinI0?si=q8XImXbidC3Eche2",
    "Utilization of Electrical Energy": "https://youtu.be/LqrIi5KMyFs?si=p1dBB0bkq3R7mrhK",
    "Smart Grids": "https://youtu.be/67AmVJlJcRc",
    "Energy Management": "https://youtu.be/R7-RGRbsEg8?si=q0kF9qEtLqcui_D1",
    "Industrial Automation": "https://youtu.be/tw-79FiRYKA?si=vzlF-B0_aoio-dZ-",
    "Power Electronics": "https://www.youtube.com/live/1_7jCgTU1Ks?si=8wWEwMTTsBEdy9fP",

    # Default placeholder
    "Project": "https://youtu.be/KnKXWcVDQiU"  # General guidance
}


        self.setup_styles()
        self.create_widgets()

    def setup_styles(self):
        style = ttk.Style()
        style.configure("TLabel", font=("Segoe UI", 12), background="#f7f8fa", foreground="#333")
        style.configure("TButton", font=("Segoe UI", 14), padding=10, relief="flat", background="#4CAF50", foreground="white")
        style.map("TButton",
                  background=[('active', '#45a049'), ('pressed', '#388e3c')],
                  relief=[('pressed', 'sunken'), ('active', 'raised')])
        style.configure("TEntry", font=("Segoe UI", 12), padding=8, relief="flat", foreground="#555")
        style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"), foreground="#4CAF50")

    def create_widgets(self):
        container = tk.Frame(self.root, bg="#ffffff", bd=1, relief="solid")
        container.pack(padx=40, pady=40, fill="both", expand=True)

        tk.Label(container, text="🎓 Student Performance Analysis", font=("Segoe UI", 24, "bold"), bg="#ffffff", fg="#333").pack(pady=25)

        form_frame = tk.Frame(container, bg="#ffffff")
        form_frame.pack(pady=15)

        # Student name
        ttk.Label(form_frame, text="Student Name:").grid(row=0, column=0, sticky="w", padx=10, pady=8)
        self.name_entry = ttk.Entry(form_frame, width=35)
        self.name_entry.grid(row=0, column=1, pady=8)

        # Department dropdown
        ttk.Label(form_frame, text="Department:").grid(row=1, column=0, sticky="w", padx=10, pady=8)
        self.dept_var = tk.StringVar()
        self.dept_dropdown = ttk.Combobox(form_frame, textvariable=self.dept_var, values=list(self.subject_map.keys()), state="readonly", width=30)
        self.dept_dropdown.grid(row=1, column=1, pady=8)
        self.dept_dropdown.current(0)

        # Semester dropdown
        ttk.Label(form_frame, text="Semester:").grid(row=2, column=0, sticky="w", padx=10, pady=8)
        self.sem_var = tk.StringVar()
        self.sem_dropdown = ttk.Combobox(form_frame, textvariable=self.sem_var, values=["1st", "2nd", "3rd", "4th", "5th", "6th"], state="readonly", width=30)
        self.sem_dropdown.grid(row=2, column=1, pady=8)
        self.sem_dropdown.current(0)

        # Subject entry frame
        self.entries_frame = tk.Frame(container, bg="#ffffff")
        self.entries_frame.pack(fill="both", expand=True, padx=10, pady=20)

        # Bind dropdown changes
        self.dept_dropdown.bind("<<ComboboxSelected>>", lambda e: self.update_subjects())
        self.sem_dropdown.bind("<<ComboboxSelected>>", lambda e: self.update_subjects())

        self.update_subjects()

        # Submit button
        style = ttk.Style()
        style.configure(
            "Custom.TButton",
            font=("Helvetica", 12, "bold"),  # Bold font
            foreground="black",              # Black text color
            padding=10
            )
        
        ttk.Button(
            container,
            text="🎯 Classify Performance",
            command=self.classify_student,
            style="Custom.TButton"
        ).pack(pady=30, ipadx=20, ipady=10)
    


    def update_subjects(self):
        # Clear old entries
        for widget in self.entries_frame.winfo_children():
            widget.destroy()
        self.entries.clear()

        dept = self.dept_var.get()
        sem = self.sem_var.get()
        self.current_subjects = self.subject_map.get(dept, {}).get(sem, [])

        if not self.current_subjects:
            tk.Label(self.entries_frame, text="No subjects available.", bg="#ffffff", fg="red").pack()
            return

        ttk.Label(self.entries_frame, text="Enter Marks for Each Subject:", style="Header.TLabel").pack(anchor="w", pady=(10, 5))


        for subject in self.current_subjects:
            row = tk.Frame(self.entries_frame, bg="#f9f9f9")  # Light background for better visibility
            row.pack(fill="x", padx=10, pady=5)

            ttk.Label(row, text=subject, font=("Segoe UI", 10, "bold")).pack(side="left", anchor="w", padx=5)
            entry = ttk.Entry(row, width=10)
            entry.pack(side="right", padx=5)
            self.entries.append(entry)
    

    def open_link(self, url):
        webbrowser.open_new_tab(url)

    # Classification logic with UI enhancements
    def classify_student(self):
       name = self.name_entry.get().strip()
       try:
           marks = [float(entry.get()) for entry in self.entries]
           classifier = StudentClassifier(marks)
           category = classifier.classify()

           low_score_subjects = []
           for mark, subject in zip(marks, self.current_subjects):
               if mark < 50:
                   link = self.video_links.get(subject, "Link not available")
                   low_score_subjects.append((subject, link))

           self.show_result_window(name, category, low_score_subjects)

       except ValueError:
           messagebox.showerror("Invalid Input", "Please enter valid numeric marks.")

    

    def show_result_window(self, name, category, low_subjects):
        result_win = tk.Toplevel(self.root)
        result_win.title("📊 Result Summary")
        result_win.geometry("520x450")
        result_win.configure(bg="#ffffff")

        # Header
        header = f"Student: {name}\nPerformance Level: {category}"
        tk.Label(result_win, text=header, font=("Segoe UI", 13, "bold"), bg="#ffffff", fg="#333333").pack(pady=15)

        # Suggested Videos Section
        if low_subjects:
            tk.Label(
                result_win,
                text="📚 Subjects to Improve (Click to Watch)",
                font=("Segoe UI", 12, "underline"),
                bg="#ffffff",
                fg="#1976D2"  # Soft blue
            ).pack(pady=10)

            for subject, url in low_subjects:
                btn = tk.Button(
                    result_win,
                    text=subject,
                    font=("Segoe UI", 11, "bold"),
                    fg="#ffffff",
                    bg="#4CAF50",  # Green shade
                    activebackground="#45A049",
                    relief="raised",
                    bd=2,
                    cursor="hand2",
                    command=lambda url=url: self.open_link(url)
                )
                btn.pack(fill="x", padx=40, pady=5, ipadx=5, ipady=3)
        else:
            tk.Label(
                result_win,
                text="🎉 Great job! No weak subjects.",
                font=("Segoe UI", 11, "italic"),
                bg="#ffffff",
                fg="#388E3C"
            ).pack(pady=10)
     

if __name__ == "__main__":
    root = tk.Tk()
    app = AppGUI(root)
    root.mainloop()
