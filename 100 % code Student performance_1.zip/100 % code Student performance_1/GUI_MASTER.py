import tkinter as tk
from subprocess import call
from PIL import Image, ImageTk
from tkinter import ttk

root = tk.Tk()
root.title("Student Performance System")

# Set the screen size to full
w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))

# Set background color for the window
root.configure(background="#f4f4f9")

# Title label for the window
lbl = tk.Label(root, text="Student Performance Prediction System", font=('Helvetica', 35, 'bold'), height=2, width=62, bg="#192841", fg="white")
lbl.place(x=0, y=0)



# Function to call the external Python script
def call_files():
    call(['python', 'test.py'])

# Button for performance analysis
button4 = tk.Button(root, text="Performance Analysis based on Marks", command=call_files, width=35, height=2, 
                    bg="#560319", fg="white", font=("Helvetica", 14, "bold"), relief="solid", bd=2)
button4.place(x=425, y=300)

# Exit button
exit_button = tk.Button(root, text="Exit", command=root.quit, width=15, height=2, font=('Helvetica', 15, 'bold'), 
                        bg="purple", fg="white", relief="solid", bd=2)
exit_button.place(x=875, y=300)



# Run the Tkinter event loop
root.mainloop()
